package com.example.activeMQ;
import java.io.File;
import java.io.PrintWriter;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;

public class ConsumerThread implements Runnable {
	// URL of the JMS server
	private static String url = ActiveMQConnection.DEFAULT_BROKER_URL;
	// default broker URL is : tcp://localhost:61616"
	ActiveMQConnectionFactory connectionFactory = null;
	 PrintWriter pw=null;
	 String numberofTimes="";
	 MessageConsumer consumer = null;
	// Name of the queue we will receive messages from
	public ConsumerThread(ActiveMQConnectionFactory connectionFactory, PrintWriter lopw,String lonumberofTimes,MessageConsumer loconsumer) {
		this.connectionFactory = connectionFactory;
		this.pw=lopw;
		numberofTimes=lonumberofTimes;
		consumer=loconsumer;
	}

	
	@Override
	public void run() {
	
		try{
			 pw.println("Start the File");
			 pw.flush();
//		Connection connection = connectionFactory.createConnection();
//		connection.start();
//		System.out.println("Connection start");
//		// Creating session for seding messages
//		Session session = connection.createSession(false,
//				Session.AUTO_ACKNOWLEDGE);
//
//		// Getting the queue 'SAMPLEQUEUE'
//		Destination destination = session.createQueue(ApplicationConstants.queueName);
//		System.out.println("got queue,destination="+destination.toString());
//		// MessageConsumer is used for receiving (consuming) messages
//		MessageConsumer consumer = session.createConsumer(destination);
//		System.out.println("got consumer, number of times:"+Integer.parseInt(numberofTimes));
//		// Here we receive the message.
//		// By default this call is blocking, which means it will wait
//		// for a message to arrive on the queue.
		Message message = consumer.receive();
		if (message instanceof TextMessage) {
			TextMessage textMessage = (TextMessage) message;
			System.out.println("Got the text message");
			System.out.println("textMessage is null:"+(textMessage==null));
			System.out.println("Receivedage '" + textMessage.getText()
			+ "'");
			 pw.println("[i]:"+textMessage);
			 pw.flush();
		}
		/*
		for(int i=0;i<Integer.parseInt(numberofTimes);i++){
		Message message = consumer.receive();
		 pw.println("["+i+"]:"+message.toString());
		// There are many types of Message and TextMessage
		// is just one of them. Producer sent us a TextMessage
		// so we must cast to it to get access to its .getText()
		// method.
		if (message instanceof TextMessage) {
			TextMessage textMessage = (TextMessage) message;
			System.out.println("Got the text message");
			System.out.println("textMessage is null:"+(textMessage==null));
			System.out.println("Receivedage '" + textMessage.getText()
			+ "'");
			 pw.println("["+i+"]:"+textMessage);
			 pw.flush();
		}
		
		  try{
			  System.out.println("Calling sleep");
			  Thread.sleep(1000);
			  }catch(InterruptedException e)
		  {
				  System.out.println(e);
				  } 
		}*/ 
		
//		  session.close();
//		connection.close();
		}catch(Exception ex){
			System.out.println("Exception in consumer Thread:"+ex.getMessage());
			ex.printStackTrace();
		}
	}
}