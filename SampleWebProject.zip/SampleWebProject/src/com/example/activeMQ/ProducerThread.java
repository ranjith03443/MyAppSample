package com.example.activeMQ;

import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;

public class ProducerThread implements Runnable {

	// Connection Factory which will help in connecting to ActiveMQ serer
	ActiveMQConnectionFactory connectionFactory = null;
	String subject="SAMPLEQUEUE";
	String textMessage="";
	String numberofTimes="";
	
	public ProducerThread(ActiveMQConnectionFactory connectionFactory,String loTextMessage,String lonumberofTimes) {
		this.connectionFactory = connectionFactory;
		textMessage=loTextMessage;
		numberofTimes=lonumberofTimes;
	}

	@Override
	public void run() {
		try {Connection connection = connectionFactory.createConnection();
		connection.start();
		// JMS messages are sent and received using a Session. We will
		// create here a non-transactional session object. If you want
		// to use transactions you should set the first parameter to 'true'
		Session session = connection.createSession(false,
				Session.AUTO_ACKNOWLEDGE);
		// Destination represents here our queue 'VALLYSOFTQ' on the
		// JMS server. You don't have to do anything special on the
		// server to create it, it will be created automatically.
		Destination destination = session.createQueue(ApplicationConstants.queueName);
		// MessageProducer is used for sending messages (as opposed
		// to MessageConsumer which is used for receiving them)
		MessageProducer producer = session.createProducer(destination);
		// We will send a small text message saying 'Hello' in Japanese
		TextMessage message = session.createTextMessage(textMessage);
		// Here we are sending the message!
		
		System.out.println("numberofTimes:"+numberofTimes);
		for(int i=0;i<Integer.parseInt(numberofTimes);i++){
			producer.send(message);	
		}
		
		System.out.println("Sent Message '" + message.getText() + "'");

		connection.close();
		} catch (JMSException jmse) {
			System.out.println("Exception: " + jmse.getMessage());
		}
	}

}