package com.example.activeMQ;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Servlet implementation class ActiveMQInitiateTransaction
 */
@WebServlet("/ActiveMQInitiateTransaction")
public class ActiveMQInitiateTransaction extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 private static final Logger logger = LogManager.getLogger(ActiveMQInitiateTransaction.class);
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ActiveMQInitiateTransaction() {
        super();
        
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		//LogManager.
		System.out.println("ENTER in to ActiveMQInitiateTransaction");
		//Log4jConfiguration ll=new Log4jConfiguration();
		
		logger.debug("ENTER in to ActiveMQInitiateTransaction");
		String enteredMessage=request.getParameter("message");
		String numberOfThreads=request.getParameter("numberofTimes");
		
//		Date curDate = new Date();
//		SimpleDateFormat format = new SimpleDateFormat("dd_MM_yyyy_HHmmss");
//		
//		 File Fileright = new File(ApplicationConstants.MQReport+format.format(curDate)+".csv");
//
//         PrintWriter pw = new PrintWriter(Fileright);
        
         ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(ApplicationConstants.MQUserName,ApplicationConstants.MQpassword,
 				ApplicationConstants.MQBrokerURL);
         
                 
//         Thread producerThread = new Thread(new ProducerThread(connectionFactory,enteredMessage,numberOfThreads));
//         producerThread.start();
         
         ProduceMessages prodMsgs=new ProduceMessages(connectionFactory,enteredMessage,numberOfThreads);
         prodMsgs.createMessages();
         
         response.getOutputStream().println("Messages written to the queue");
        // Thread consumerThread = new Thread(new ConsumerThread(connectionFactory,pw,numberOfThreads));
       //  consumerThread.start();
       
     //    pw.close();
		
	}

}
