package com.example.activeMQ;

import java.io.File;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.activemq.ActiveMQConnectionFactory;

public class runProducerManually {
	
	public static void main(String args[]){
		
		try{
			
			Date curDate = new Date();
			SimpleDateFormat format = new SimpleDateFormat("dd_MM_yyyy_HHmmss");
			
			 File Fileright = new File(ApplicationConstants.MQReport+format.format(curDate)+".csv");

	         PrintWriter pw = new PrintWriter(Fileright);
	        
	         ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(ApplicationConstants.MQUserName,ApplicationConstants.MQpassword,
	 				ApplicationConstants.MQBrokerURL);
	         
	                 System.out.println("Enter in to runComsumerManually");	   
	                 String enteredMessage="This is a text message";
	                 String numberOfThreads="400";
	                 Thread producerThread = new Thread(new ProducerThread(connectionFactory,enteredMessage,numberOfThreads));
	                 producerThread.start();
	       
	         //pw.close();
			
			
		}catch(Exception ex){
			System.out.println("Exceptin ex:"+ex.getMessage());
		}
		
	}

}
