package com.example.activeMQ;
import java.io.File;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;



public class runComsumerManually {
	
	public static void main(String args[]){
		
		try{
			
			Date curDate = new Date();
			SimpleDateFormat format = new SimpleDateFormat("dd_MM_yyyy_HHmmss");
			
			 File Fileright = new File(ApplicationConstants.MQReport+format.format(curDate)+".csv");

	         PrintWriter pw = new PrintWriter(Fileright);
	        
	         ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(ApplicationConstants.MQUserName,ApplicationConstants.MQpassword,
	 				ApplicationConstants.MQBrokerURL);
	         
	                 System.out.println("Enter in to runComsumerManually");	   
	                 Connection connection = connectionFactory.createConnection();
	         		connection.start();
	         		System.out.println("Connection start");
//	         		// Creating session for seding messages
	         		Session session = connection.createSession(false,
	         				Session.AUTO_ACKNOWLEDGE);
	                 Destination destination = session.createQueue(ApplicationConstants.queueName);
//	         		System.out.println("got queue,destination="+destination.toString());
//	         		// MessageConsumer is used for receiving (consuming) messages
	         		
	              //   MessageConsumer consumer = session.createConsumer(destination);
	                 Thread consumerThread = null;
	       //  int i=0;
//	         while(i<400){
//	        	 consumerThread = new Thread(new ConsumerThread(connectionFactory,pw,"400",consumer));
//	        	 consumerThread.start();
//	        	 i++;
//	         }
//	         consumerThread.stop();
	         //pw.close();
	         for (int i = 0; i < 4; i++) {
					MessageConsumer consumer = session.createConsumer(destination);
					consumer.setMessageListener(new ConsumerMessageListener("Consumer "+i,pw));
				}
			
			
		}catch(Exception ex){
			System.out.println("Exceptin ex:"+ex.getMessage());
		}
		
	}

}
