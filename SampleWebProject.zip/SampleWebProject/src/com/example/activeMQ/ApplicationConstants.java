package com.example.activeMQ;

public class ApplicationConstants {
	
	public static final String queueName="SAMPLEQUEUE";
	public static final String MQUserName="admin";
	public static final String MQpassword="admin";
	public static final String MQBrokerURL="tcp://localhost:61616";
	public static final String MQReport="E:\\MyWorkspace\\ConsumerReport\\ConsumerReport_";
	public static final int MQThreadSleep=1000;
	

}
