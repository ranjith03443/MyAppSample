package com.sample.MQ;

import javax.jms.Connection;

import org.apache.activemq.ActiveMQConnectionFactory;

public class MQMina {
	
	public static void main(String[] args){
		
		try{
			
			// Create the connection factory
			ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory("admin","admin",
					"tcp://localhost:61616");

			// Create the consumer. It will wait to listen to the Topic
			Thread topicConsumerThread = new Thread(new TopicConsumer(
					connectionFactory));
			topicConsumerThread.start();

			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			// Create a message. As soon as the message is published on the Topic,
			// it will be consumed by the consumer
			Thread topicProducerThread = new Thread(new TopicProducer(
					connectionFactory));
			topicProducerThread.start();
			
		}catch(Exception ex){
			System.out.println("Exception in main:"+ex.getMessage());
			
		}
		
	}
}
